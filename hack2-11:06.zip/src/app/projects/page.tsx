export default function ProjectsPage() {
  return (
    <main className="flex h-full w-full items-center justify-center border">
      <h1 className="text-xl text-gray-600/50">Please select a project</h1>
    </main>
  );
}
