import CreateProjectForm from "./_components/CreateProjectForm";

export default async function CreateProjectPage() {
  return (
    <main className="h-screen w-full">
      <CreateProjectForm />
    </main>
  );
}
